# Family Learning — 0.1.2

Mobile-first, buildless browser application. The web edition is prepared for GitHub Pages under santos-cabbigat/Family-Learning. No ChatGPT runtime connection, application server, or remote student database. A signed Android APK is now available, with bundled offline assets, a stable local HTTPS WebView origin, native file export/import, photo selection, and printing. iPhone/iPad currently use the Safari home-screen web edition; a signed native iOS binary has not been produced. Native iOS code updates must follow Apple distribution rules.

## Implemented

- IndexedDB local storage with transactional saves, per-origin write locking where supported, and tab change notifications.
- Shared, immutable teaching editions; separate child assignment IDs and append-only attempts.
- Material editor, parent guide, practice questions, answer keys, reference notes, edition printing.
- Individual plans and portfolios with notes, scores, feedback, optional worksheet images.
- Portable JSON recovery files. Imports validate schema and references, reject conflicting IDs, and keep current records when merging the same family.
- Manual Drive adapter: explicit Google authorization, download/merge snapshots, upload a fresh snapshot, download it again for verification, then mark only included IDs synced. Previous snapshots are never deleted.
- Size and time reminders for unsynced records. Export does not falsely count as a verified Drive sync.
- PWA app shell and Settings update checks. New service worker activation requires the Apply update action while an existing edition is running.

## Setup still required

`docs/config.json` deliberately has no Google OAuth credentials. Configure a Google Cloud project under the family's control, enable Drive API, register the browser origin for a Web OAuth client, configure the consent screen and allowed users, and set `googleClientId` (a public client identifier). No client secret belongs in the frontend. `googleApiKey` and `googleAppId` are reserved and unused; this edition lists app-created backups directly and does not implement Picker.

The adapter uses Google's Identity Services token client, with access tokens in memory only. Expired access requires another user-initiated sign-in. It requests `drive.file`, and uses a visible Family Learning folder for backups created by this application. Different family members' independent Google accounts and shared-folder Picker access require further setup and testing. The first supported connection is one parent-controlled Google account across the family's devices. Do not place that account's password in the app.

Live Drive OAuth/upload/restore has not been tested without that configuration. Multi-device consistency needs real-account testing. Photos use inline JSON storage for this early edition (maximum 10 MB each and 100 MB recovery import); large libraries need separate asset uploads, resumable transport, and delta sync before broad use. The current adapter merges full snapshots and preserves them all.

This is a **parent workspace**, not a child security boundary. Dedicated child accounts, restricted access to answer keys, and per-child authentication are not implemented. Offline storage remains device/browser dependent. Confirm on physical iPad/iPhone/Android devices before relying on it. No closed-app notifications or background data sync. No AI provider or online research connection.

## Development and deployment

`node --test tests/*.test.js`

Static deployment root: `docs/`. Serve from HTTPS for service workers. Bump `VERSION` in core.js, version.json, the cache name in sw.js, and displayed release labels together when publishing a new version. Keep IndexedDB migrations backward compatible; never delete stored user data during a code update.

Source and deployed versions are preserved in the personal GitHub repository. Configure Settings → Pages → Deploy from a branch → main → /docs. The docs folder is the publishing root; source, tests, and signing instructions are outside it. The hosted address is required for first browser install and web updates. Google Drive is the intended data backup/sync destination, not the website host.

## Android build and installation release

Run `python native/android/build.py SDK_DIRECTORY OUTPUT_DIRECTORY PRIVATE_SIGNING_DIRECTORY`. The SDK directory contains `tools/android-15` from Android build tools 35.0.0 and `platform/android-35` from platform 35 revision 2. The script verifies the APK after signing and outputs manifest metadata. Preserve the same private signing key for all subsequent updates. Private signing material is saved separately and must never be included in the hosted files or source repository.

Package `com.familylearning.app`, minimum Android 8 (API 26), versionCode 3. The Android app uses the system WebView, and opens without ChatGPT authentication. Direct Drive OAuth is intentionally disabled in the embedded WebView; use native file export/import until a proper native Google authorization flow is configured. Settings opens the GitHub Pages update/download page. This is an explicit download and Android-confirmed update, not a silent updater.

This release moves the app address and Android update/download links to the personal GitHub Pages site. Safari installation has not been verified on a physical iPhone. APK signature and manifest verified; device launch and native picker behavior require physical-device testing.

## Hosting migration and recovery

Target website: https://santos-cabbigat.github.io/Family-Learning/

Before leaving the old ChatGPT Sites website, use Sync → Export recovery file. Open the new website and import that file. Browsers keep each website address in separate storage; moving the code does not move saved records. Repeat for each device that has unsaved work, merging recovery files as needed. Never upload recovery JSON or personal lesson files to this code repository.

Android users install 0.1.2 over 0.1.1, without uninstalling. The package name, signing certificate, and local storage origin stay the same. The new update link then uses GitHub Pages.

The published website and source code are public. They contain only app code and labelled sample content. Family records are saved locally and, after Google setup, in the Google account the parent explicitly authorizes. The website does not serve records from other devices. Anyone using an unlocked device/browser profile can access its local workspace.

Publication status must be checked on GitHub Pages before sharing the target website as live. Google Drive synchronization remains unconfigured until the family-owned Google OAuth project is set up; moving hosting does not enable it.
