#!/usr/bin/env python3
"""Build Family Learning using verified Android SDK 35 tools, without Gradle."""
from pathlib import Path
import hashlib, json, os, secrets, shutil, subprocess, sys, zipfile

root=Path(__file__).resolve().parents[2]
sdk=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
signing=Path(sys.argv[3]).resolve()
tools=sdk/'tools/android-15'
android=next((sdk/'platform').rglob('android.jar'))
for f in tools.iterdir():
 if f.is_file() and f.suffix not in ['.txt','.jar']: f.chmod(0o755)
out.mkdir(parents=True,exist_ok=True)
signing.mkdir(parents=True,exist_ok=True);signing.chmod(0o700)
password_file=signing/'password.txt';key=signing/'family-learning.p12'
if not password_file.exists():
 password_file.write_text(secrets.token_urlsafe(36));password_file.chmod(0o600)
env=os.environ.copy();env['FAMILY_SIGNING_PASSWORD']=password_file.read_text().strip()
def run(*args,**kw):subprocess.run([str(a) for a in args],check=True,env=env,**kw)
if not key.exists():
 run('keytool','-genkeypair','-keystore',key,'-storetype','PKCS12','-storepass:env','FAMILY_SIGNING_PASSWORD','-keypass:env','FAMILY_SIGNING_PASSWORD','-alias','family-learning','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=Family Learning, OU=Family Applications, O=Family Learning')
 key.chmod(0o600)
assets=out/'assets/www';assets.mkdir(parents=True,exist_ok=True)
for f in (root/'docs').iterdir():
 if f.is_file():shutil.copy2(f,assets/f.name)
shutil.copy2(root/'docs/icon-192.png',root/'native/android/res/drawable/app_icon.png')
classes=out/'classes';classes.mkdir(exist_ok=True)
generated=out/'generated';generated.mkdir(exist_ok=True)
dex=out/'dex';dex.mkdir(exist_ok=True)
run(tools/'aapt2','compile','--dir',root/'native/android/res','-o',out/'resources.zip')
run(tools/'aapt2','link','-o',out/'base.apk','-I',android,'--manifest',root/'native/android/AndroidManifest.xml','--java',generated,'-A',out/'assets',out/'resources.zip')
sources=list((root/'native/android/src').rglob('*.java'))+list(generated.rglob('*.java'))
run('java','--module','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(tools/'core-lambda-stubs.jar')+os.pathsep+str(android),'-d',classes,*sources)
run('java','-cp',tools/'lib/d8.jar','com.android.tools.r8.D8','--min-api','26','--lib',android,'--output',dex,*classes.rglob('*.class'))
unsigned=out/'unsigned.apk';shutil.copy2(out/'base.apk',unsigned)
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED) as z:
 for f in dex.glob('*.dex'):z.write(f,f.name)
run(tools/'zipalign','-f','4',unsigned,out/'aligned.apk')
final=out/'Family-Learning-0.1.2.apk'
run('java','-jar',tools/'lib/apksigner.jar','sign','--ks',key,'--ks-key-alias','family-learning','--ks-pass','env:FAMILY_SIGNING_PASSWORD','--key-pass','env:FAMILY_SIGNING_PASSWORD','--out',final,out/'aligned.apk')
run('java','-jar',tools/'lib/apksigner.jar','verify','--verbose','--print-certs',final)
run(tools/'aapt2','dump','badging',final)
verification={'version':'0.1.2','package':'com.familylearning.app','sha256':hashlib.sha256(final.read_bytes()).hexdigest(),'bytes':final.stat().st_size,'physical_device_tested':False}
(out/'verification.json').write_text(json.dumps(verification,indent=2))
print(json.dumps(verification))
