package com.familylearning.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import org.json.JSONObject;

public final class MainActivity extends Activity {
  private static final String HOST="appassets.androidplatform.net";
  private static final String START="https://"+HOST+"/index.html";
  private static final int SAVE=41,OPEN=42,PHOTO=43;
  private WebView web;
  private String pendingExport;
  private ValueCallback<Uri[]> photoCallback;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    web=new WebView(this);
    web.setBackgroundColor(0xfff7f8f3);
    WebSettings settings=web.getSettings();
    settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);settings.setAllowFileAccess(false);
    settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setUserAgentString(settings.getUserAgentString()+" FamilyLearningAndroid/0.1.2");
    web.addJavascriptInterface(new NativeBridge(),"FamilyNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
        Uri u=request.getUrl();if(!HOST.equals(u.getHost()))return null;
        String path=u.getPath();if(path==null||path.equals("/"))path="/index.html";
        if(path.contains("..")||!request.getMethod().equals("GET"))return errorResponse();
        try {String mime=path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".json")||path.endsWith(".webmanifest")?"application/json":path.endsWith(".svg")?"image/svg+xml":path.endsWith(".png")?"image/png":"text/html";
          WebResourceResponse response=new WebResourceResponse(mime,"UTF-8",getAssets().open("www"+path));
          HashMap<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");headers.put("X-Content-Type-Options","nosniff");headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' https://www.googleapis.com; object-src 'none'; frame-src 'none'; base-uri 'none'");response.setResponseHeaders(headers);return response;
        }catch(Exception e){return errorResponse();}
      }
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){if(HOST.equals(request.getUrl().getHost())&&"https".equals(request.getUrl().getScheme()))return false;if(request.isForMainFrame())openExternal(request.getUrl());return true;}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(photoCallback!=null)photoCallback.onReceiveValue(null);photoCallback=callback;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("image/*");
        try{startActivityForResult(intent,PHOTO);}catch(Exception e){photoCallback.onReceiveValue(null);photoCallback=null;message("No file picker is available on this device.");}return true;
      }
    });
    setContentView(web);web.loadUrl(START);
  }
  private WebResourceResponse errorResponse(){return new WebResourceResponse("text/plain","UTF-8",404,"Not found",new HashMap<>(),new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));}
  private void openExternal(Uri uri){String s=uri.getScheme();if(!"https".equals(s)&&!"http".equals(s))return;try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){message("Open this link in your browser: "+uri);}}
  private void message(String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show());}
  private void callback(String fn,String value){runOnUiThread(()->web.evaluateJavascript("window."+fn+" && window."+fn+"("+JSONObject.quote(value)+");",null));}
  public final class NativeBridge {
    @JavascriptInterface public String version(){return "0.1.2";}
    @JavascriptInterface public void saveBackup(String json,String name){runOnUiThread(()->{if(pendingExport!=null){message("Finish the current save first.");return;}if(json.length()>140*1024*1024){message("This recovery file is too large for this edition.");return;}pendingExport=json;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^a-zA-Z0-9._-]","_"));try{startActivityForResult(i,SAVE);}catch(Exception e){pendingExport=null;message("A file-saving app is required.");}});}
    @JavascriptInterface public void openBackup(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});try{startActivityForResult(i,OPEN);}catch(Exception e){message("A file picker is required.");}});}
    @JavascriptInterface public void openUpdates(){runOnUiThread(()->openExternal(Uri.parse("https://santos-cabbigat.github.io/Family-Learning/?android_version=0.1.2#install")));}
    @JavascriptInterface public void openFamilyFolder(){runOnUiThread(()->openExternal(Uri.parse("https://drive.google.com/drive/folders/1ZLhhfXYCfRtMJMt91wLcbVtM9dZ-sUTp")));}
    @JavascriptInterface public void printPage(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("Family Learning",web.createPrintDocumentAdapter("Family Learning"),null);});}
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==PHOTO){if(photoCallback!=null){photoCallback.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);photoCallback=null;}return;}
    if(request==SAVE){final String text=pendingExport;pendingExport=null;if(result!=RESULT_OK||data==null||data.getData()==null){callback("nativeBackupFinished","cancelled");return;}final Uri uri=data.getData();new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception("No output stream");out.write(text.getBytes(StandardCharsets.UTF_8));out.flush();callback("nativeBackupFinished","saved");}catch(Exception e){callback("nativeBackupFinished","failed");}}).start();return;}
    if(request==OPEN&&result==RESULT_OK&&data!=null&&data.getData()!=null){final Uri uri=data.getData();new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new Exception("File unavailable");byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>100*1024*1024)throw new Exception("Choose a backup below 100 MB.");out.write(buffer,0,n);}callback("nativeImportBackup",new String(out.toByteArray(),StandardCharsets.UTF_8));}catch(Exception e){callback("nativeImportFailed",e.getMessage());}}).start();}
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else new AlertDialog.Builder(this).setTitle("Close Family Learning?").setMessage("Save any work on the current form before closing.").setNegativeButton("Stay",null).setPositiveButton("Close",(d,w)->finish()).show();}
  @Override protected void onDestroy(){if(photoCallback!=null)photoCallback.onReceiveValue(null);web.removeJavascriptInterface("FamilyNative");web.destroy();super.onDestroy();}
}
